package engine.item;

public class Foret extends ElementCarte {

	//Constructeur de la class
	public Foret() {
		super("Foret");
	}
	
}
