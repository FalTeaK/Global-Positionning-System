package engine.item;

public class Route extends Chemin {

	//Constructeur de la Classe
	public Route() {
		super("Route",5,3);
	}
	
}
