package engine.item;

public class Rail extends Chemin {
	
	private int comfort;
	//Constructeur de la Classe
	public Rail() {
		super("Rail", 80,1);
		this.comfort=1;
	}
	
}
