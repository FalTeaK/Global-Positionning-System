package engine.item;

public class Eau extends ElementCarte {

	//Constructeur de la case eau
	public Eau() {
		super("Eau");
	}
	
}
