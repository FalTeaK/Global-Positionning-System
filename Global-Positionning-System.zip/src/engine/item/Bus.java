package engine.item;

public class Bus extends Chemin {
	private String name;
	
	public Bus(String name) {
		super("Bus", 40,1);
		this.name=name;
	}

}
