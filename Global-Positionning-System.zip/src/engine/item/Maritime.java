package engine.item;

public class Maritime extends Chemin{

	//constructeur de la classe
	public Maritime() {
		super("Maritime", 10,2);
	}
	
}
