package engine.exception;

public class WrongParametersException extends Exception {
	private static final long serialVersionUID = 1L;

	public WrongParametersException(String title) {
		super(title);
	}

}



